import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie.dart';

class MovieService {
  static const String apiKey = 'afb91c29041e91108fa21141d3f30053';
  static const String baseUrl = 'https://api.themoviedb.org/3';

  Future<List<Movie>> fetchNowPlaying() async {
    final response = await http.get(Uri.parse('$baseUrl/movie/now_playing?api_key=$apiKey&language=pt-BR'));
    if (response.statusCode == 200) {
      final List results = json.decode(response.body)['results'];
      return results.map((json) => Movie.fromJson(json)).toList();
    } else {
      throw Exception('Erro ao carregar filmes');
    }
  }
}