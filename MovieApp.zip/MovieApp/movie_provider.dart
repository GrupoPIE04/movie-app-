import 'package:flutter/foundation.dart';
import 'movie.dart';
import 'movie_service.dart';

class MovieProvider extends ChangeNotifier {
  final MovieService _service = MovieService();
  List<Movie> _movies = [];
  bool _isLoading = false;

  List<Movie> get movies => _movies;
  bool get isLoading => _isLoading;

  Future<void> loadNowPlaying() async {
    _isLoading = true;
    notifyListeners();
    _movies = await _service.fetchNowPlaying();
    _isLoading = false;
    notifyListeners();
  }
}