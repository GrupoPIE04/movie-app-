# MovieApp

A Flutter application that connects to the TMDb API to display current movies with a modern and intuitive interface.

## Features

- Displays a list of currently showing movies.
- Detailed view for each movie, including synopsis, cast, and trailers.
- Search functionality to find movies by title.

## Project Structure

```
MovieApp
├── lib
│   ├── main.dart                  # Entry point of the application
│   ├── models
│   │   └── movie.dart             # Movie model definition
│   ├── services
│   │   └── tmdb_api_service.dart   # Service for TMDb API requests
│   ├── screens
│   │   ├── home_screen.dart        # Home screen displaying current movies
│   │   └── movie_detail_screen.dart # Detailed view of a selected movie
│   ├── widgets
│   │   ├── movie_card.dart         # Widget for displaying a single movie
│   │   └── movie_list.dart         # Widget for displaying a list of movies
│   └── utils
│       └── constants.dart          # Constants used throughout the app
├── pubspec.yaml                    # Flutter project configuration
└── README.md                       # Project documentation
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd MovieApp
   ```

3. Install dependencies:
   ```
   flutter pub get
   ```

4. Replace the TMDb API key in `lib/utils/constants.dart`.

5. Run the application:
   ```
   flutter run
   ```

## API Key

To use the TMDb API, you need to obtain an API key from [TMDb](https://www.themoviedb.org/documentation/api). Add your API key in the `constants.dart` file.

## License

This project is licensed under the MIT License.